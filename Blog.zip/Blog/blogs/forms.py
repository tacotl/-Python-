from django import forms

from .models import BlogPost

class BlogPostForm(forms.ModelForm):
	class Meta:
		model = BlogPost
		fields = ['title','text']  # 获取模型里的两个字段
		widgets = {'text': forms.Textarea(attrs={'cols':80})}

class BlogForm(forms.ModelForm):
	class Meta:
		model = BlogPost
		fields = ['title','text']  
		labels = {'text':'','title':''}
		widgets = {'text': forms.Textarea(attrs={'cols':80})}
		