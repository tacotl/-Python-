from django.shortcuts import render

# Create your views here.
from .models import Pizza  # 导入显示所有主题关联的模型


def index(request):
    """披萨店的主页""" # 这里不需要处理数据，因此只调用了rander()
    return render(request, 'pizzas/index.html')
    # 这里向函数render()提供了两个实参：对象request以及一个可用于创建页面的模板


def pizza_names(request):
    """显示所有披萨的页面"""
    pizza_names = Pizza.objects.order_by('date_added')
    context = {'pizza_names': pizza_names}
    return render(request, 'pizzas/pizza_names.html', context)


def pizza_name(request, pizza_name_id):  # 注意形参包含piz_name_id
    """显示特定主题的页面"""
    pizza_name = Pizza.objects.get(id=pizza_name_id)  # 查询：通过get()获取指定的主题
    toppings = pizza_name.topping_set.order_by('-date_added')  # 查询：获取与该主题相关联的条目，
    # 并根据date_added排列，注意前面减号-指定按降序排列，即先显示最近的。
    context = {'pizza_name': pizza_name, 'toppings': toppings}  # 主题和条目都存在字典context中
    return render(request, 'pizzas/pizza_name.html', context)


