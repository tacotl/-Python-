from django.urls import path  

from . import views  

app_name = 'pizzas'  
urlpatterns = [  
    # 主页
    path('', views.index, name='index'),  
    # 显示所有主题
    path('pizza_names/', views.pizza_names, name='pizza_names'),
    path('pizza_name/<int:pizza_name_id>/', views.pizza_name, name='pizza_name'),
]

