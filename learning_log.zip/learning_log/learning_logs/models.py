# 在这里创建模型
from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Topic(models.Model):
	"""用户学习的主题"""
	# 添加text和date_added两个属性
	# 属性text 是一个CharField ——由字符组成的数据，即文本（。需要存储少量文本，如名称、标题或城市时，可使用CharField 。定义CharField 属性时，必须告诉Django该在数据库中预留多少空间。这里将max_length 设置成了200（即200字符），这对存储大多数主题名来说足够了。
	text = models.CharField(max_length=200)
	# 属性date_added 是一个DateTimeField——记录日期和时间的数据。我们传递了实参auto_now_add=True，每当用户创建新主题时，Django都会将这个属性自动设置为当前日期和时间。
	date_added = models.DateTimeField(auto_now_add=True)
	owner = models.ForeignKey(User,on_delete=models.CASCADE)

	def __str__(self):
		"""返回模型的字符串表示"""
		return self.text

class Entry(models.Model):
	"""学到的某个主题的具体知识"""
	topic = models.ForeignKey(Topic,on_delete=models.CASCADE)
	text = models.TextField()
	date_added = models.DateTimeField(auto_now_add=True)

	class Meta:
		verbose_name_plural = 'entries'

	def __str__(self):
		"""返回模型的字符串表示"""
		return f"{self.text[:50]}..."
		