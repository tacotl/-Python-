import plotly.express as px

for key in px.colors.named_colorscales():
	print(key)