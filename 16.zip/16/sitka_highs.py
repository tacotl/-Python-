import csv

import matplotlib.pyplot as plt

from datetime import datetime


# filename = 'D:/Sublime Text/python_test/16/sitka_weather_07-2018_simple.csv'
filename = 'D:/Sublime Text/python_test/16/sitka_weather_2018_simple.csv'
with open(filename) as f:
	reader = csv.reader(f)
	# 模块csv包含函数next()，调用它并传入阅读器对象时，它将返回文件中的下一行
	header_row = next(reader) 
	
	# # 调用enumerate()来获取每个元素的索引及其值。
	# for index,colum_header in enumerate(header_row):
	# 	print(index,colum_header)

	# 从文件中获取日期和最高值
	dates,highs = [],[]
	for row in reader:
		current_date = datetime.strptime(row[2],'%Y-%m-%d')
		high = int(row[5])
		dates.append(current_date)
		highs.append(high)

	# 根据最高温度绘制图形
	plt.style.use('seaborn')
	fig,ax = plt.subplots()
	ax.plot(dates,highs,c='red')

	# 设置图形的格式
	# ax.set_title('2018年7月每日最高温度',fontsize=24)
	ax.set_title('the highest weather in 2018',fontsize=24)
	ax.set_xlabel('',fontsize=16)
	ax.set_ylabel('温度(F)',fontsize=16)
	ax.tick_params(axis='both',which='major',labelsize=16)

	plt.show()


	# first_date = datetime.strptime('2018-07-01','%Y-%m-%d')
	# print(first_date)











