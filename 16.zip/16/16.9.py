import csv

import plotly.express as px

import plotly.graph_objects as go

import pandas as pd

import json


data= pd.read_csv('D:/Sublime Text/python_test/16/world_fires_1_day.csv')
data.head()

fig = go.Figure(go.Densitymapbox(lat=data['latitude'],
								 lon=data['longitude'],
								 z=data['brightness'],
								 radius=4))
fig.update_layout(mapbox_style="open-street-map")


fig.show()

# if __name__ == '__main__':
# 	print(mags[:10])
# 	print(titles[:2])
# 	print(lons[:5])
# 	print(lats[:5])

# datas= pd.read_csv('D:/Sublime Text/python_test/16/world_fires_1_day.csv')
# datas.head()


# lats,lons,zs = [],[],[]
# for data in datas:
# 	lats.append(data[0])
# 	lons.append(data[1])
# 	zs.append(data[2])

# fig = go.Figure(go.Densitymapbox(lat=lats,
# 								 lon=lons,
# 								 z=zs,
# 								 radius=4))
# fig.update_layout(mapbox_style="open-street-map")
# fig.show()