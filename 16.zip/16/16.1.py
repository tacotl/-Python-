import csv

import matplotlib.pyplot as plt

from datetime import datetime

filename = 'D:/Sublime Text/python_test/16/sitka_weather_2018_simple.csv'

with open(filename) as f:
	reader = csv.reader(f)
	header_row = next(reader)

	# 从文件中获取每日降水量
	prcps = []
	for row in reader:
		prcp = float(row[3])
		prcps.append(prcp)

# 根据每日降水量绘制图形
plt.style.use('seaborn')
fig,ax = plt.subplots()
ax.plot(prcps,c='red')

# 设置图形格式
ax.set_title('锡特卡的降雨量',fontsize=24)
ax.set_xlabel('',fontsize=16)
ax.set_ylabel('PRCP',fontsize=16)

# 显示表格
plt.show()