import csv 

import matplotlib.pyplot as plt

from datetime import datetime

def weather_data(filename,dates,highs,lows,t_date,t_high,t_low):
	
	with open(filename) as f:
		reader = csv.reader(f)
		header_row = next(reader)

		# 从文件中获取日期、最高温度和最低温度
		for row in reader:
			current_date = datetime.strptime(row[t_date],'%Y-%m-%d')
			try:
				high = int(row[t_high])
				low = int(row[t_low])
			except ValueError:
				print(f'Missing data for {current_date}')
			else:
				dates.append(current_date)
				highs.append(high)
				lows.append(low)


# 获得锡特卡的温度
filename = 'D:/Sublime Text/python_test/16/sitka_weather_2018_simple.csv'
dates,highs,lows = [],[],[]
weather_data(filename,dates,highs,lows,t_date=2,t_high=5,t_low=6)

# 根据锡特卡的数据绘制图形
plt.style.use('seaborn')
fig,ax = plt.subplots()
ax.plot(dates,highs,c='red',alpha=0.7)
ax.plot(dates,lows,c='green',alpha=0.7)
plt.fill_between(dates,highs,lows,facecolor='green',alpha=0.1)

# 获得死亡谷的温度
filename = 'D:/Sublime Text/python_test/16/death_valley_2018_simple.csv'
dates,highs,lows = [],[],[]
weather_data(filename,dates,highs,lows,t_date=2,t_high=4,t_low=5)

# 根据死亡谷的数据绘制图形
ax.plot(dates,highs,c='red',alpha=0.7)
ax.plot(dates,lows,c='blue',alpha=0.7)
plt.fill_between(dates,highs,lows,facecolor='blue',alpha=0.1)

# 设置图形的格式
ax.set_title('Sitaka and Death Vally temperatures',fontsize=24)
ax.set_xlabel('',fontsize=16)
ax.set_ylabel('temperature(F)',fontsize=16)
ax.tick_params(axis='both',which='major',labelsize=16)
plt.ylim(10,130)

# 显示表格
plt.show()



