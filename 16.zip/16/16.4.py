import csv 

import matplotlib.pyplot as plt

from datetime import datetime

filename = 'D:/Sublime Text/python_test/16/sitka_weather_2018_simple.csv'
filename = 'D:/Sublime Text/python_test/16/death_valley_2018_simple.csv'
place_name = ''
	
with open(filename) as f:
	reader = csv.reader(f)
	header_row = next(reader)
	t_name = header_row.index('NAME')
	t_date = header_row.index('DATE')
	t_high = header_row.index('TMAX')
	t_low = header_row.index('TMIN')

	# 从文件中获取日期、最高温度和最低温度
	dates,highs,lows = [],[],[]
	for row in reader:
		# 如果没有气象站名字，就获取它
		if not place_name:
			place_name = row[t_name]
			print(place_name)

		current_date = datetime.strptime(row[t_date],'%Y-%m-%d')
		try:
			high = int(row[t_high])
			low = int(row[t_low])
		except ValueError:
			print(f'Missing data for {current_date}')
		else:
			dates.append(current_date)
			highs.append(high)
			lows.append(low)

# 根据最高气温和最低气温绘制图形
plt.style.use('seaborn')
fig,ax = plt.subplots()
ax.plot(dates,highs,c='red',alpha=0.7)
ax.plot(dates,lows,c='green',alpha=0.7)
plt.fill_between(dates,highs,lows,facecolor='green',alpha=0.1)


# 设置图形的格式
ax.set_title('Sitaka and Death Vally temperatures',fontsize=24)
ax.set_xlabel('',fontsize=16)
ax.set_ylabel('temperature(F)',fontsize=16)
ax.tick_params(axis='both',which='major',labelsize=16)

# 显示表格
plt.show()



